// File: mobileapp/src/main/java/com/sai/talentassessment/ApiClient.java
package com.sai.talentassessment;

public class ApiClient {
    // IMPORTANT: Use this address when the server and app are on the SAME phone.
    // 127.0.0.1 is a special address that means "localhost" or "this device".
    private static final String BASE_URL = "http://127.0.0.1:8080/api/v1/";

    public static String getBaseUrl() {
        return BASE_URL;
    }

    // In a real app, you would use a library like Retrofit here
    // to define methods for each API endpoint (e.g., submitAssessment).
}

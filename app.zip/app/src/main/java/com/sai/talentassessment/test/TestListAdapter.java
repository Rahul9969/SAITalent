 // PASTE THIS ENTIRE CORRECTED CODE BLOCK INTO TestListAdapter.java

package com.sai.talentassessment.test;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.sai.talentassessment.data.Test;
import java.util.List;

public class TestListAdapter extends RecyclerView.Adapter<TestListAdapter.TestViewHolder> {

    private final List<Test> testList;
    private final Context context;
    private final String athleteId;

    public TestListAdapter(Context context, List<Test> testList, String athleteId) {
        this.context = context;
        this.testList = testList;
        this.athleteId = athleteId;
    }

    @NonNull
    @Override
    public TestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // We create a simple TextView programmatically for each list item
        TextView itemView = new TextView(parent.getContext());
        itemView.setPadding(40, 40, 40, 40);
        itemView.setTextSize(20f);
        return new TestViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TestViewHolder holder, int position) {
        Test currentTest = testList.get(position);
        holder.bind(currentTest);
    }

    @Override
    public int getItemCount() {
        return testList.size();
    }

    // The ViewHolder class that holds the view for each item
    class TestViewHolder extends RecyclerView.ViewHolder {
        // This is the view for one list item
        TextView testNameTextView;

        public TestViewHolder(@NonNull View itemView) {
            super(itemView);
            // We cast the itemView to our TextView
            testNameTextView = (TextView) itemView;
        }

        public void bind(final Test test) {
            testNameTextView.setText(test.getName());

            // Set the click listener on the item view
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, RecordVideoActivity.class);
                    intent.putExtra("TEST_NAME", test.getName());
                    intent.putExtra("ATHLETE_ID", athleteId);
                    context.startActivity(intent);
                }
            });
        }
    }
}
